CREATE DATABASE IF NOT EXISTS apotek_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE apotek_db;

CREATE TABLE obat (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_obat VARCHAR(100) NOT NULL,
    jenis_obat VARCHAR(50) NOT NULL,
    prioritas ENUM('Tinggi', 'Sedang', 'Rendah') NOT NULL DEFAULT 'Sedang',
    tanggal DATE NOT NULL,
    status ENUM('belum', 'selesai') NOT NULL DEFAULT 'belum',
    dibuat_pada TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO obat (nama_obat, jenis_obat, prioritas, tanggal, status) VALUES
('Paracetamol 500 mg', 'Analgesik', 'Tinggi', '2025-01-10', 'selesai'),
('Amoxicillin 500 mg', 'Antibiotik', 'Tinggi', '2025-01-11', 'belum'),
('Vitamin C 1000 mg', 'Suplemen', 'Rendah', '2025-01-12', 'belum'),
('OBH Combi', 'Obat Batuk', 'Sedang', '2025-01-13', 'belum');
