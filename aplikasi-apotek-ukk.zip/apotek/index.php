<?php
session_start();
require_once __DIR__ . '/fungsi.php';

$filter  = $_GET['filter'] ?? 'semua';
$daftar  = ambilSemua($filter);
$total   = count(ambilSemua());
$selesai = count(ambilSemua('selesai'));
$pesan   = $_SESSION['pesan'] ?? null;
unset($_SESSION['pesan']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Aplikasi Apotek</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
  <h1>Aplikasi Website Apotek</h1>
  <p class="ringkas">Total: <?= $total ?> | Selesai: <?= $selesai ?> | Belum: <?= $total - $selesai ?></p>

  <?php if ($pesan): ?>
    <div class="alert <?= e($pesan['jenis']) ?>"><?= e($pesan['teks']) ?></div>
  <?php endif; ?>

  <div class="card">
    <h2>Tambah Obat</h2>
    <form action="proses.php" method="post">
      <input type="hidden" name="aksi" value="tambah">
      <div class="grid">
        <input type="text" name="nama_obat" placeholder="Nama obat" maxlength="100" required>
        <input type="text" name="jenis_obat" placeholder="Jenis obat" maxlength="50" required>
        <select name="prioritas" required>
          <option value="Tinggi">Prioritas Tinggi</option>
          <option value="Sedang" selected>Prioritas Sedang</option>
          <option value="Rendah">Prioritas Rendah</option>
        </select>
        <input type="date" name="tanggal" value="<?= date('Y-m-d') ?>" required>
      </div>
      <button class="btn btn-primary">+ Tambah</button>
    </form>
  </div>

  <div class="filter">
    <?php foreach (['semua' => 'Semua', 'belum' => 'Belum Selesai', 'selesai' => 'Selesai'] as $k => $label): ?>
      <a href="?filter=<?= $k ?>" class="<?= $filter === $k ? 'aktif' : '' ?>"><?= $label ?></a>
    <?php endforeach; ?>
  </div>

  <div class="card">
    <?php if (!$daftar): ?>
      <p class="kosong">Belum ada data obat.</p>
    <?php else: ?>
      <table>
        <thead>
          <tr><th>No</th><th>Nama Obat</th><th>Jenis</th><th>Prioritas</th><th>Tanggal</th><th>Status</th><th>Aksi</th></tr>
        </thead>
        <tbody>
        <?php foreach ($daftar as $i => $o): $done = $o['status'] === 'selesai'; ?>
          <tr class="<?= $done ? 'done' : '' ?>">
            <td><?= $i + 1 ?></td>
            <td><?= e($o['nama_obat']) ?></td>
            <td><?= e($o['jenis_obat']) ?></td>
            <td><span class="badge <?= strtolower($o['prioritas']) ?>"><?= e($o['prioritas']) ?></span></td>
            <td><?= e($o['tanggal']) ?></td>
            <td><?= $done ? '✓ Selesai' : '• Belum' ?></td>
            <td class="aksi">
              <a class="btn btn-info" href="proses.php?aksi=selesai&id=<?= $o['id'] ?>"><?= $done ? 'Batal' : 'Selesai' ?></a>
              <a class="btn btn-warning" href="edit.php?id=<?= $o['id'] ?>">Edit</a>
              <a class="btn btn-danger" href="proses.php?aksi=hapus&id=<?= $o['id'] ?>" onclick="return confirm('Hapus data ini?')">Hapus</a>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</div>
</body>
</html>
