<?php
session_start();
require_once __DIR__ . '/fungsi.php';

function redirect(string $pesan, string $jenis = 'sukses', string $ke = 'index.php'): never {
    $_SESSION['pesan'] = ['teks' => $pesan, 'jenis' => $jenis];
    header("Location: $ke");
    exit;
}

$aksi = $_REQUEST['aksi'] ?? '';
$id   = (int) ($_REQUEST['id'] ?? 0);

switch ($aksi) {
    case 'tambah':
        $err = validasi($_POST);
        if ($err) redirect(implode(' ', $err), 'error');
        $ok = tambahObat($_POST);
        redirect($ok ? 'Obat ditambahkan.' : 'Gagal menambah.', $ok ? 'sukses' : 'error');
    case 'edit':
        $err = validasi($_POST);
        if ($err) redirect(implode(' ', $err), 'error', "edit.php?id=$id");
        $ok = ubahObat($id, $_POST);
        redirect($ok ? 'Data diperbarui.' : 'Gagal memperbarui.', $ok ? 'sukses' : 'error', "edit.php?id=$id");
    case 'selesai':
        $ok = toggleStatus($id);
        redirect($ok ? 'Status diubah.' : 'Gagal mengubah status.', $ok ? 'sukses' : 'error');
    case 'hapus':
        $ok = hapusObat($id);
        redirect($ok ? 'Obat dihapus.' : 'Gagal menghapus.', $ok ? 'sukses' : 'error');
    default:
        redirect('Aksi tidak dikenali.', 'error');
}
