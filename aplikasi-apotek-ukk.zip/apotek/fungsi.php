<?php
require_once __DIR__ . '/config.php';

function e(?string $s): string {
    return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8');
}

function validasi(array $d): array {
    $err = [];
    if (trim($d['nama_obat'] ?? '') === '') $err[] = 'Nama obat wajib diisi.';
    if (trim($d['jenis_obat'] ?? '') === '') $err[] = 'Jenis obat wajib diisi.';
    if (!in_array($d['prioritas'] ?? '', ['Tinggi', 'Sedang', 'Rendah'], true)) $err[] = 'Prioritas tidak valid.';
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $d['tanggal'] ?? '')) $err[] = 'Tanggal tidak valid.';
    return $err;
}

function ambilSemua(string $filter = 'semua'): array {
    global $conn;
    $where = in_array($filter, ['belum', 'selesai'], true) ? "WHERE status = '$filter'" : '';
    $sql = "SELECT * FROM obat $where ORDER BY FIELD(prioritas, 'Tinggi', 'Sedang', 'Rendah'), tanggal ASC";
    return mysqli_fetch_all(mysqli_query($conn, $sql), MYSQLI_ASSOC);
}

function ambilById(int $id): ?array {
    global $conn;
    $stmt = mysqli_prepare($conn, "SELECT * FROM obat WHERE id = ?");
    mysqli_stmt_bind_param($stmt, 'i', $id);
    mysqli_stmt_execute($stmt);
    return mysqli_fetch_assoc(mysqli_stmt_get_result($stmt)) ?: null;
}

function ambilObatById(int $id): ?array {
    return ambilById($id);
}

function tambahObat(array $d): bool {
    global $conn;
    $stmt = mysqli_prepare($conn, "INSERT INTO obat (nama_obat, jenis_obat, prioritas, tanggal) VALUES (?, ?, ?, ?)");
    $nama = trim($d['nama_obat']);
    $jenis = trim($d['jenis_obat']);
    mysqli_stmt_bind_param($stmt, 'ssss', $nama, $jenis, $d['prioritas'], $d['tanggal']);
    return mysqli_stmt_execute($stmt);
}

function ubahObat(int $id, array $d): bool {
    global $conn;
    $stmt = mysqli_prepare($conn, "UPDATE obat SET nama_obat=?, jenis_obat=?, prioritas=?, tanggal=? WHERE id=?");
    $nama = trim($d['nama_obat']);
    $jenis = trim($d['jenis_obat']);
    mysqli_stmt_bind_param($stmt, 'ssssi', $nama, $jenis, $d['prioritas'], $d['tanggal'], $id);
    return mysqli_stmt_execute($stmt);
}

function toggleStatus(int $id): bool {
    global $conn;
    $stmt = mysqli_prepare($conn, "UPDATE obat SET status = IF(status='belum','selesai','belum') WHERE id=?");
    mysqli_stmt_bind_param($stmt, 'i', $id);
    return mysqli_stmt_execute($stmt);
}

function hapusObat(int $id): bool {
    global $conn;
    $stmt = mysqli_prepare($conn, "DELETE FROM obat WHERE id=?");
    mysqli_stmt_bind_param($stmt, 'i', $id);
    return mysqli_stmt_execute($stmt);
}
