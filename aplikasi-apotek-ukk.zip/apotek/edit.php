<?php
session_start();
require_once __DIR__ . '/fungsi.php';

$id = (int) ($_GET['id'] ?? 0);
$obat = ambilById($id);
if (!$obat) {
    $_SESSION['pesan'] = ['teks' => 'Data tidak ditemukan.', 'jenis' => 'error'];
    header('Location: index.php');
    exit;
}
$pesan = $_SESSION['pesan'] ?? null;
unset($_SESSION['pesan']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Edit Obat</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
  <h1>Edit Obat</h1>
  <?php if ($pesan): ?>
    <div class="alert <?= e($pesan['jenis']) ?>"><?= e($pesan['teks']) ?></div>
  <?php endif; ?>
  <div class="card">
    <form action="proses.php" method="post">
      <input type="hidden" name="aksi" value="edit">
      <input type="hidden" name="id" value="<?= $obat['id'] ?>">
      <div class="grid">
        <input type="text" name="nama_obat" value="<?= e($obat['nama_obat']) ?>" maxlength="100" required>
        <input type="text" name="jenis_obat" value="<?= e($obat['jenis_obat']) ?>" maxlength="50" required>
        <select name="prioritas" required>
          <?php foreach (['Tinggi', 'Sedang', 'Rendah'] as $p): ?>
            <option value="<?= $p ?>" <?= $obat['prioritas'] === $p ? 'selected' : '' ?>>Prioritas <?= $p ?></option>
          <?php endforeach; ?>
        </select>
        <input type="date" name="tanggal" value="<?= e($obat['tanggal']) ?>" required>
      </div>
      <button class="btn btn-primary">Simpan</button>
      <a href="index.php" class="btn">Batal</a>
    </form>
  </div>
</div>
</body>
</html>
